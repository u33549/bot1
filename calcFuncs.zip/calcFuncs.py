import deepl

def translate_text(text,role1,role2):
    src=detectLang(role1)
    dest=detectLang(role2)
    # dest="en"

    if src==dest:
        return "33549#translateCode#same"

    elif src=="":
        return "33549#translateCode#uhnr"
    print("log1")
    result = deepl.translate(text=text,src=src, dest=dest)


    return result.text






def detectLang(roles):
    langs=['af', 'sq', 'am', 'ar', 'hy', 'az', 'eu', 'be', 'bn', 'bs', 'bg', 'ca', 'ceb', 'ny', 'zh-cn', 'zh-tw', 'co', 'hr', 'cs', 'da', 'nl', 'en', 'eo', 'et', 'tl', 'fi', 'fr', 'fy', 'gl', 'ka', 'de', 'el', 'gu', 'ht', 'ha', 'haw', 'iw', 'he', 'hi', 'hmn', 'hu', 'is', 'ig', 'id', 'ga', 'it', 'ja', 'jw', 'kn', 'kk', 'km', 'ko', 'ku', 'ky', 'lo', 'la', 'lv', 'lt', 'lb', 'mk', 'mg', 'ms', 'ml', 'mt', 'mi', 'mr', 'mn', 'my', 'ne', 'no', 'or', 'ps', 'fa', 'pl', 'pt', 'pa', 'ro', 'ru', 'sm', 'gd', 'sr', 'st', 'sn', 'sd', 'si', 'sk', 'sl', 'so', 'es', 'su', 'sw', 'sv', 'tg', 'ta', 'te', 'th', 'tr', 'uk', 'ur', 'ug', 'uz', 'vi', 'cy', 'xh', 'yi', 'yo', 'zu']
    for role in roles:
        name =role.name.lower();
        if(name in langs):
            return name
    return ""

def isInText(text,q):
    if(text.find(q)==-1):
        return False
    else:
        return True