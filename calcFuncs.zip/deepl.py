import time
import urllib.parse
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

chrome_options = Options()
chrome_options.add_argument("--headless")
driver = webdriver.Chrome(options=chrome_options)




def translate(src,dest,text):
    driver.get(f"https://www.deepl.com/translator#{src}/{dest}/{urllib.parse.quote(text)}")
    while True:
        try:
            res =driver.find_element(By.CSS_SELECTOR,".lmt__inner_textarea_container > d-textarea > div > p > span")
            return res;
        except Exception as error:
            # print(error)
            time.sleep(0.05)
            pass


